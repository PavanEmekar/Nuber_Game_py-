import random
import time

print("Welcom to the guessing game")
time.sleep(2)

print("You have to guess a number bitween 1 and 100 whitch I have chosen")
time.sleep(3)

Guess = int(input("Please input your guess here and press Enter: "))
Ans = random.randint(1,100)
Atempts = 1
while Guess != Ans:
  Atempts += 1
  print("Incorect")
  if Guess < Ans:
    print("Guess again but HIGHER")
  elif Guess > Ans:
    print("Guess again but LOWER")
  
  Guess = int(input("Please input your guess now:"))
  time.sleep(3)
print(f"Congratulations you have guessed the correct number and it took you {Atempts}  attempts")
